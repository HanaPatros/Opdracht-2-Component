﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication10.Models;

namespace WebApplication10.Controllers
{
    public class ComponentController : Controller
    {
        private ComponentContext db = new ComponentContext();
          
       

    
        public ActionResult Index(string sortOrder,string searchString)
        {
            var componenten = db.Componenten.Include(c => c.Categorie);

            if (!String.IsNullOrEmpty(searchString))
            {
                componenten = componenten.Where(s =>
               s.Naam.ToUpper().Contains(searchString.ToUpper())
                );
            }

            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "naam_desc" : "";
            if (String.IsNullOrEmpty(sortOrder))
            {
                componenten = componenten.OrderBy(s => s.Naam);
            }

            if (sortOrder == "naam_desc")
            {
                componenten = componenten.OrderByDescending(s => s.Naam);
            }

            return View(componenten.ToList());
        }
        // GET: /Component/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Models.Component component = db.Componenten.Find(id);
            if (component == null)
            {
                return HttpNotFound();
            }
            return View(component);
        }
        [Authorize]
        // GET: /Component/Create
        public ActionResult Create()
        {
            ViewBag.CategorieId = new SelectList(db.Categorieën, "CategorieId", "CategorieNaam");
            return View();
        }
            [Authorize]
        // POST: /Component/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Naam,DataSheet,Aantal,Aankoopprijs,CategorieId")] Models.Component component)
        {
            if (ModelState.IsValid)
            {
                db.Componenten.Add(component);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategorieId = new SelectList(db.Categorieën, "CategorieId", "CategorieNaam", component.CategorieId);
            return View(component);
        }
            [Authorize]
        // GET: /Component/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Models.Component component = db.Componenten.Find(id);
            if (component == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategorieId = new SelectList(db.Categorieën, "CategorieId", "CategorieNaam", component.CategorieId);
            return View(component);
        }
            [Authorize]
        // POST: /Component/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Naam,DataSheet,Aantal,Aankoopprijs,CategorieId")] Models.Component component)
        {
            if (ModelState.IsValid)
            {
                db.Entry(component).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategorieId = new SelectList(db.Categorieën, "CategorieId", "CategorieNaam", component.CategorieId);
            return View(component);
        }
            [Authorize]
        // GET: /Component/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Models.Component component = db.Componenten.Find(id);
            if (component == null)
            {
                return HttpNotFound();
            }
          
            return View(component);
        }
            [Authorize]
        // POST: /Component/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Models.Component component = db.Componenten.Find(id);
            db.Componenten.Remove(component);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
