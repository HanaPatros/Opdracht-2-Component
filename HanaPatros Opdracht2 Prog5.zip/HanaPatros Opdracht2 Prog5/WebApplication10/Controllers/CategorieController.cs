﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication10.Models;

namespace WebApplication10.Controllers
{
    public class CategorieController : Controller
    {
        private ComponentContext db = new ComponentContext();

        // GET: /Categorie/
        public ActionResult Index(int? id)
        {
            if (id != null)
            {
                ViewBag.InstructorID = id.Value;
                //Cursussen die gegeven worden door een bepaalde instructor
                //viewModel.Courses = viewModel.Instructors.Where(
                //    i => i.ID == id.Value).SingleOrDefault().Courses;
                ViewBag.ComponentsByCategory = db.Categorieën.Where(
                    i => i.CategorieId == id.Value).SingleOrDefault().ComponentList;
            }
            var CategoryList = db.Categorieën.ToList();
            return View(CategoryList);
        }

        // GET: /Categorie/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Categorie categorie = db.Categorieën.Find(id);
            if (categorie == null)
            {
                return HttpNotFound();
            }
            return View(categorie);
        }
        [Authorize]
        // GET: /Categorie/Create
        public ActionResult Create()
        {
            return View();
        }
         [Authorize]
        // POST: /Categorie/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="CategorieId,CategorieNaam")] Categorie categorie)
        {
            if (ModelState.IsValid)
            {
                db.Categorieën.Add(categorie);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(categorie);
        }
         [Authorize]
        // GET: /Categorie/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Categorie categorie = db.Categorieën.Find(id);
            if (categorie == null)
            {
                return HttpNotFound();
            }
            return View(categorie);
        }
         [Authorize]
        // POST: /Categorie/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="CategorieId,CategorieNaam")] Categorie categorie)
        {
            if (ModelState.IsValid)
            {
                db.Entry(categorie).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(categorie);
        }
         [Authorize]
        // GET: /Categorie/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Categorie categorie = db.Categorieën.Find(id);
            if (categorie == null)
            {
                return HttpNotFound();
            }
            return View(categorie);
        }
         [Authorize]
        // POST: /Categorie/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Categorie categorie = db.Categorieën.Find(id);
            db.Categorieën.Remove(categorie);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
