﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace WebApplication10.Models
{
    public class Categorie
    {
        public int CategorieId { get; set; }

        [Required]
        public string CategorieNaam { get; set; }

        public virtual ICollection<Component> ComponentList{get;set;}
    }
}
