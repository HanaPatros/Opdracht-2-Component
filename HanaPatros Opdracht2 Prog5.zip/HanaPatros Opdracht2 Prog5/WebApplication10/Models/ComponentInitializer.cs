﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication10.Models
{
    public class ComponentInitializer : DropCreateDatabaseIfModelChanges<ComponentContext>
    {
        protected override void Seed(ComponentContext context)
        {           


            var Categorie1 = new Categorie(){CategorieId=1, CategorieNaam ="Hardware" };
            var Categorie2 = new Categorie() { CategorieId = 2, CategorieNaam = "Software" };


            var categorieList = new List<Categorie>() { Categorie1, Categorie2 };

            categorieList.ForEach(s => context.Categorieën.Add(s));
            context.SaveChanges();




            var componentList = new List<Component>
            {                

                new Component
                {
                    Naam = "Condensator",
                    Categorie = Categorie1,
                    Aankoopprijs = 20,
                    Aantal = 50,
                    DataSheet = "https://nl.wikipedia.org/wiki/Condensator"
                },
                new Component
                {
                    Naam = "Processor",
                    Categorie = Categorie1,
                    Aankoopprijs = 220,
                    Aantal = 50,
                    DataSheet = "https://nl.wikipedia.org/wiki/Processor_(computer)"
                },
                new Component
                {
                    Naam = "Moederbord",
                    Categorie = Categorie1,
                    Aankoopprijs = 120,
                    Aantal = 50,
                    DataSheet = "https://nl.wikipedia.org/wiki/Moederbord"
                }


            };
            componentList.ForEach(s => context.Componenten.Add(s));
            context.SaveChanges();


           



        }
    }
}