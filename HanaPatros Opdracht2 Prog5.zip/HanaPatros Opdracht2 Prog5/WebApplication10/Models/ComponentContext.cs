﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication10.Models
{
    public class ComponentContext : DbContext
    {
        public DbSet<Component> Componenten { get; set; }
        public DbSet<Categorie> Categorieën { get; set; }

        public ComponentContext()
        {
            Database.SetInitializer<ComponentContext>(new ComponentInitializer());
        }
    }
}